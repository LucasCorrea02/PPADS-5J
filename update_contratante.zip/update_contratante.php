<?php
  // conctando ao BD
  include "conecta_mysql.php";

  $nomecomp = $_POST['nomecomp'];
  $senha = $_POST['senha'];
  $confisenha = $_POST['confisenha'];
  $email = $_POST['email'];
  $datanasc = $_POST['datanasc'];
  $servofer = $_POST['servofer'];
  
  // executando a operação de SQL
  $resultado = mysqli_query($conexao, "UPDATE alunos SET nome='".$nomecomp."', senha=".$senha." , confisenha = ".$confisenha.", email = ".$email.", datanasc = ".$datanasc.", WHERE senhaha =".$senha) or die("Não foi possível executar a SQL: ".mysqli_error($conexao));

  if($resultado === TRUE){
	echo "<br/>Usuário atualizado com sucesso!";
  } else {
        echo "<br/>Erro na atualização!";
  }
  // fechamento da conexão   
  mysqli_close($conexao);
?>
