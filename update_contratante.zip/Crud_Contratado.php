<?php
    $opcao = $_POST['tipoCRUD'];
    switch($opcao)
    {
        case "C":
            $formulario = "<h3>CRIAR</h3>
                <form action='create.php' method='POST'>
                    NOMEComp: <input type='text' name='nomecomp'/><br/>
                    SENHA: <input type='password' name='senha'/><br/>
                    ConfSenha: <input type='password' name='confisenha'/><br/>
                    Email: <input type='email' name='email'/><br/>
                    DataNasc: <input type='date' name='datanasc'/><br/>
                    ServOfer: <input type='text' name='servofer'/><br/>
                    <input type='submit' value='INSERIR'/>
                </form>";
        break;
        
                
        case "R":
            $formulario = "<h3>BUSCAR</h3>
                <form action='read.php' method='POST'>
                    <input type='submit' value='BUSCAR'/>
                </form>";
        break;
        
        case "U":
            $formulario = "<h3>ATUALIZAR</h3>
                <form action='update.php' method='POST'>
                    NOMEComp: <input type='text' name='nomecomp'/><br/>
                    SENHA: <input type='password' name='senha'/><br/>
                    ConfSenha: <input type='password' name='confisenha'/><br/>
                    Email: <input type='email' name='email'/><br/>
                    DataNasc: <input type='date' name='datanasc'/><br/>
                    ServOfer: <input type='text' name='servofer'/><br/>
                    <input type='submit' value='ATUALIZAR'/>
                </form>";
        break;
        
        case "D":
           $formulario = "<h3>APAGAR</h3>
                <form action='delete.php' method='POST'>
                    Email: <input type='email' name='email'/><br/>
                    <input type='submit' value='REMOVER'/>
                </form>";
        break; 
    }
    echo $formulario;

?>